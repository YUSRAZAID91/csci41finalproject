//Adam Barron-Gonzalez & Yusra Aldhari

#ifndef SECTION1_H
#define SECTION1_H

void section1();

#endif
