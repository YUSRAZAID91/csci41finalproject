//Adam Barron-Gonzalez & Yusra Aldhari
// This program is the shopping cart

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include "section4.h"

using namespace std;

// Function prototypes
void viewCart();
void shopItems();
void clearCart();

// Function to display cart
void viewCart() {
    // File handling and variables
    ifstream inFile("cart.txt");
    if (!inFile) {
        cout << "Error opening the file." << endl;
        return;
    }

    const double TAX_RATE = 0.07;
    int totalItems = 0;
    double subtotal = 0.0;
    double taxes = 0.0;
    string shipping = "FREE";
    double total = 0.0;

    // Display cart header
    cout << "  -*-*-*-*- Your Cart -*-*-*-*-" << endl << endl;
    cout << setprecision(2) << fixed;

    cout << setw(5) << "No." << setw(20) << "Product" << setw(12) << "Price(USD)" << setw(12) << "Weight(oz)" << endl;
    cout << "----------------------------------------------" << endl;

    // Read and display cart items
    string product;
    float price;
    double weight;
    int lineCount = 1;

    while (inFile >> product >> price >> weight) {
        cout << setw(5) << lineCount++ << setw(20) << product << setw(12) << price << " " << weight << endl;
        totalItems++;
        subtotal += price;
    }

    inFile.close();

    // Calculate taxes and total
    taxes = subtotal * TAX_RATE;
    total = subtotal + taxes;

    // Display cart summary
    cout << endl;
    cout << left << setw(20) << "Total items:" << right << setw(5) << totalItems << endl;
    cout << left << setw(20) << "Subtotal:" << right << setw(5) << "$" << setw(10) << subtotal << endl;
    cout << left << setw(20) << "Tax Rate:" << right << setw(5) << setprecision(0) << TAX_RATE * 100 << "%" << endl;
    cout << setprecision(2) << left << setw(20) << "Taxes:" << right << setw(5) << "$" << setw(10) << taxes << endl;
    cout << left << setw(20) << "Shipping:" << right << setw(5) << "$" << setw(10) << shipping << endl;
    cout << left << setw(20) << "Total after taxes:" << right << setw(5) << "$" << setw(10) << total << endl;

    // Wait for user input to continue
    cout << endl << "Press Enter to continue...";
    cin.ignore();
    while (cin.get() != '\n');
}

void clearCart() {
    char confirmation;
    cout << "Are you sure you want to clear your cart? Type 'Y' or 'y' to confirm or any other key to cancel: ";
    cin >> confirmation;

    // Clear the cart if the user confirms
    if (confirmation == 'Y' || confirmation == 'y') {
        ofstream outFile("cart.txt");
        outFile.close();
        cout << "Cart cleared successfully." << endl;
    }
    else {
        cout << "Cart clearing canceled." << endl;
    }
}
