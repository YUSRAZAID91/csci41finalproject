//Adam Barron-Gonzalez & Yusra Aldhari
//Function for item array. 

#include "MakeUpStoreArray.h"

void MakeUpArray::readFile() {
    MakeUpProduct item;
    string product;
    float price;
    double weight; 

    inFile.open("MakeUpStore.txt");

    if (!inFile) {
        cout << "File has not been opened" << endl;
    }
    while (!inFile.eof())
    {
        inFile >> product >> price >> weight;
        item.setProductName(product); 

        item.setWeight(weight); 

        cout << product << endl;
        cout << price << endl;
        cout << weight << endl; 
    }
}
