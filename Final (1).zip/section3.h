//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef SECTION3_H
#define SECTION3_H

void section3();

#endif
