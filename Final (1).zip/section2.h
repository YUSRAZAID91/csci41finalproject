//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef SECTION2_H
#define SECTION2_H

void section2();

#endif