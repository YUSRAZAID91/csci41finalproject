//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef SECTION6_H
#define SECTION6_H

void section6();

#endif
