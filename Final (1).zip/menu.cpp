//Adam Barron-Gonzalez & Yusra Aldhari
// This is the main menu the user is promted.

#include <iostream>
#include "MakeUpProduct.h"
#include "menu.h"
#include "section1.h"
#include "section2.h"
#include "section3.h"
#include "section4.h"
#include "section6.h"

using namespace std;

// Function for main menu
void displayMenu() {
    int choice;

    // Displays the menu and waits for user input
    do {
        cout << endl;

        // Displays the menu
        cout << "  -*-*-*-*- Welcome to Adam & Yusra's Makeup Store -*-*-*-*-" << endl << endl;
        cout << "    Please choose a section:" << endl;
        cout << "    1. (^_^) Shopping" << endl;
        cout << "    2. (o_o) Beauty Tips" << endl;
        cout << "    3. (^_~) Contact Us" << endl;
        cout << "    0. (=_=) Exit" << endl;
        cout << "    Enter your choice: ";
        cin >> choice;
        cout << endl;

        // Check for invalid input
        while (cin.fail() || choice < 0 || choice > 3) {
            cout << "Oops! Invalid choice. Please try again. (>_>)" << endl;
            cin.clear();
            cin.ignore(200, '\n');
            cout << "Enter your choice: ";
            cin >> choice;
        }

        // Process input
        switch (choice) {
        case 1:
            section1(); // List all products
            break;
        case 2:
            section3(); // Display beauty tips
            break;
        case 3:
            section6(); // Contact us
            break;
        case 0: // Exit the program
            cout << "(-_-)zZ Thank you for visiting Adam & Yusra's Makeup Store! Bye!" << endl;
            break;
        default: // Handle invalid user input
            cout << "Oops! Invalid choice. Please try again. (>_>)" << endl;
        }
    } while (choice != 0);
}
