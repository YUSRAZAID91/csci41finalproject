//Adam Barron-Gonzalez & Yusra Aldhari
// this is the submenu for the shopping


#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "section2.h"

using namespace std;

// Function prototypes
void shopItems();
void displayItemsByCategory(const string& category);
string getCategory(int choice);
void calculateTotalPrice(const string& filename, float* totalPrice);

// Shop Items section 
void section2() {
    cout << "Welcome to the Shop Items section!" << endl << endl;
    shopItems();
}

// Displays the shopping menu and takes input
void shopItems() {
    int choice;

    do {
        // Display the submenu
        cout << "Please choose a category to display items: " << endl;
        cout << "1. All" << endl;
        cout << "2. Makeup" << endl;
        cout << "3. Spa" << endl;
        cout << "4. Fragrance" << endl;
        cout << "0. Exit Shop Items section" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        cin.ignore();
        cout << endl;

        // Call displayItemsByCategory based on  input
        switch (choice) {
        case 1:
            displayItemsByCategory("All");
            break;
        case 2:
            displayItemsByCategory("Makeup");
            break;
        case 3:
            displayItemsByCategory("Spa");
            break;
        case 4:
            displayItemsByCategory("Fragrance");
            break;
        case 0:
            cout << "Exiting Shop Items section." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
        cout << endl;

        //Adds the items to the cart
        if (choice != 0) {
            int productChoice;
            cout << "Enter the number of the item you'd like to add to your cart or 0 to go back to the menu: ";
            cin >> productChoice;
            cout << endl;

            if (productChoice != 0) {
                // Opens the input and output files
                ifstream inFile("MakeupStore.txt");
                ofstream cartFile("cart.txt", ios::app);

                if (!inFile) {
                    cout << "Error opening the MakeupStore.txt file." << endl;
                    return;
                }

                string product;
                float price;
                double weight;
                string tag;

                int currentItem = 1;
                int lineCount = 1;
                // Reads the input file and add item to the cart
                while (inFile >> product >> price >> weight >> tag) {
                    if (choice == 1 || tag == getCategory(choice)) {
                        if (productChoice == lineCount++) {
                            cartFile << product << " " << price << " " << weight << endl;
                            cout << "Added " << product << " to your cart." << endl;
                            break;
                        }
                        currentItem++;
                    }
                }

                // Close the input and output files
                inFile.close();
                cartFile.close();

                // Handle invalid choices
                if (productChoice != lineCount - 1) {
                    cout << "Invalid choice. Please try again." << endl;
                }

                float totalPrice;
                calculateTotalPrice("cart.txt", &totalPrice);
                cout << "Total price of items in cart: $" << totalPrice << endl;
                cout << endl;
            }
        }
    } while (choice != 0);
}

// Gets the category based on input
string getCategory(int choice) {
    switch (
        choice) {
    case 2:
        return "Makeup";
    case 3:
        return "Spa";
    case 4:
        return "Fragrance";
    default:
        return "";
    }
}

// Displays items in selected category
void displayItemsByCategory(const string& category) {

    ifstream inFile("MakeupStore.txt");
    if (!inFile) {
        cout << "Error opening the MakeupStore.txt file." << endl;
        return;
    }

    string product;
    float price;
    double weight;
    string tag;

    // Display table
    cout << setw(5) << "No." << setw(20) << "Product" << setw(12) << "Price(USD)" << setw(12) << "Weight(oz)" << endl;
    cout << "----------------------------------------------" << endl;

    int lineCount = 1;
    // Read the input file and displays items in selected category
    while (inFile >> product >> price >> weight >> tag) {
        if (category == "All" || category == tag) {
            cout << setw(5) << lineCount++ << setw(20) << product << setw(12) << price << " " << weight << endl;
        }
    }

    // Display table
    cout << "----------------------------------------------" << endl;
    inFile.close();
}

// Calculates the total price of items in the cart
void calculateTotalPrice(const string& filename, float* totalPrice) {
    ifstream cartFile(filename);
    if (!cartFile) {
        cout << "Error opening the " << filename << " file." << endl;
        return;
    }

    string product;
    float price;
    double weight;
    *totalPrice = 0;

    while (cartFile >> product >> price >> weight) {
        *totalPrice += price;
    }

    cartFile.close();
}