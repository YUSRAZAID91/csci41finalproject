//Adam Barron-Gonzalez & Yusra Aldhari
// This is the contact us section

#include <iostream>
#include <string>

using namespace std;

// Function to display contact information
void section6() {

    // Print store contact details
    cout << "  -*-*-*-*- Contact Us -*-*-*-*-" << endl << endl;
    cout << "Store Name: Adam & Yusra's Makeup Store" << endl;
    cout << "Address: 123 Beauty Lane, Reedley, CA 98611" << endl;
    cout << "Phone: (123) 456-7890" << endl;
    cout << "Email: info@AYMakeupstore.com" << endl;
    cout << "Website: www.AYMakeupstore.com" << endl << endl;

    // Wait for user input to continue
    cout << "Press Enter to continue...";
    string clearBuffer;
    getline(cin, clearBuffer);
}