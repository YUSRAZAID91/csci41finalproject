//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef MENU_H
#define MENU_H

void displayMenu();

#endif
