//Adam Barron-Gonzalez & Yusra Aldhari
//
// This program is a store. 
//
//You can shop, view beauty tips, and see our contact information.
//When you select shopping you are able to add items to your cart, view your cart and clear your cart. 
//It savea your cart items to cart.txt. There are items in the cart for example. 
#include<iostream>
#include "menu.h"

using namespace std;

int main() {
    displayMenu();

    return 0;
}
