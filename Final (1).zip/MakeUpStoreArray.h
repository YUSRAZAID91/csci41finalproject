//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef MAKEUPARRAY_H
#define MAKEUPARRAY_H
#include <iostream>
#include <fstream>
#include "MakeUpProduct.h"

using namespace std;

class MakeUpArray {
private:
    ifstream inFile; // defining input variables for file operation
    ofstream fileOut;
    MakeUpProduct* invArray = nullptr; // declaration of dynamic array
    // using a dynamic array will allow us to change size 

public:
    void readFile();
};

#endif
