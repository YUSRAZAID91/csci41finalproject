//Adam Barron-Gonzalez & Yusra Aldhari
//This  displays a menu for skincare tips. 

#include <iostream>
#include <fstream>
#include <string>
#include "section3.h"

using namespace std;

// Function prototypes
void displaySkincareTips();
void showTipsForCategory(const string& category);

// Function for Skincare Tips
void section3() {
    cout << "  -*-*-*-*- Welcome to the Beauty Tips Section -*-*-*-*-" << endl << endl;
    displaySkincareTips();
}

// Function to display the menu for skincare tips sections
void displaySkincareTips() {
    int choice;

    do {
        //Menu
        cout << "Please choose a subject to get skincare tips:" << endl;
        cout << "1. Face" << endl;
        cout << "2. Eyes" << endl;
        cout << "3. Lips" << endl;
        cout << "4. Hair" << endl;
        cout << "5. Nails" << endl;
        cout << "6. Body" << endl;
        cout << "7. Feet" << endl;
        cout << "0. Exit Skincare Tips section" << endl;
        cout << "Enter your choice: " << endl;
        cin >> choice;

        cin.ignore();
        cout << endl;



        // Selects function depending on user input
        switch (choice) {
        case 1:
            showTipsForCategory("Face");
            break;
        case 2:
            showTipsForCategory("Eyes");
            break;
        case 3:
            showTipsForCategory("Lips");
            break;
        case 4:
            showTipsForCategory("Hair");
            break;
        case 5:
            showTipsForCategory("Nails");
            break;
        case 6:
            showTipsForCategory("Body");
            break;
        case 7:
            showTipsForCategory("Feet");
            break;
        case 0:
            cout << "Exiting Skincare Tips section." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
        cout << endl;
    } while (choice != 0);
}

// Function to output skincare tips the selected category
void showTipsForCategory(const string& category) {
    ifstream inFile("skincareTips.txt");

    // Checks if the file was opened correctly
    if (!inFile) {
        cout << "Error opening the file." << endl;
        return;
    }

    string line;

    // Search for the category name in [].
    while (getline(inFile, line)) {
        if (line == "[" + category + "]") {

            // Display the category name in the desired format
            cout << "<3 " << category << " <3" << endl << endl;

            // Read and output tips an empty line or till it runs into the next category
            while (getline(inFile, line)) {
                if (line.empty() || line[0] == '[') {
                    break;
                }
                cout << "- " << line << endl;
            }
            break;
        }
    }

    inFile.close();

    // Pause notice
    cout << endl << "Press Enter to continue..." << endl;

    // Clear the input buffer
    string clearBuffer;
    getline(cin, clearBuffer);
}