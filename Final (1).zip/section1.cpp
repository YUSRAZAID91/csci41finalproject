//Adam Barron-Gonzalez & Yusra Aldhari
// This is the shopping menu

#include <iostream>
#include <iomanip>
#include <fstream>
#include "MakeUpProduct.h"
#include "Section4.h"

using namespace std;

void shopItems();
void viewCart();
void clearCart();

// Function for shopping menu
void section1() {
    int choice;

    do {
        cout << endl;
        // Displays the shopping menu
        cout << "  -*-*-*-*- Welcome to the Shopping Section -*-*-*-*-" << endl << endl;
        cout << "1. Shop Items" << endl;
        cout << "2. View Cart" << endl;
        cout << "3. Clear Cart" << endl;
        cout << "0. Exit Shopping" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        // Check for invalid input
        while (cin.fail() || choice < 0 || choice > 3) {
            cout << "Oops! Invalid choice. Please try again. (>_>)" << endl;
            cin.clear();
            cin.ignore(200, '\n');
            cout << "Enter your choice: ";
            cin >> choice;
        }

        // Process user input
        switch (choice) {
        case 1:
            shopItems(); // List items for shopping
            break;
        case 2:
            viewCart(); // Show the user's cart
            break;
        case 3:
            clearCart(); // Clear the user's cart
            break;
        case 0: // Exit shopping section
            cout << "Exiting Shopping section." << endl;
            break;
        default: // Handle invalid input
            cout << "Invalid choice. Please try again." << endl;
            
        }
    } while (choice != 0);
}
