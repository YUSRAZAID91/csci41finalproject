//Adam Barron-Gonzalez & Yusra Aldhari

#pragma once
#ifndef MAKEUPPRODUCT_H
#define MAKEUPPRODUCT_H
#include <string>
#include <iomanip>
#include <fstream>
#include <iostream>

using namespace std;

// MakeUpProduct class definition
class MakeUpProduct {
private:
    string productName; // Product name
    float price; // Product price
    double weight; // Product weight

public:
    // Default constructor
    MakeUpProduct() : price(0.0f), weight(0.0) {}

    // Parameter constructor
    MakeUpProduct(const string& name, float p, double w)
        : productName(name), price(p), weight(w) {}

    // Getter function
    string getProductName() const { return productName; }
    float getPrice() const { return price; }
    double getWeight() const { return weight; } 

    // Setter function
    void setProductName(const string& name) { productName = name; }
    void setPrice(float p) { price = p; }
    void setWeight(double w) { weight = w; }

    // Read product information from a file
    void readFile(ifstream& inFile) {
        inFile >> productName >> price >> weight;
    }

    // Display product information
    void displayItems();

};
#endif
